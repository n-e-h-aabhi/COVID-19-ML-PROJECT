#!/usr/bin/env python
# coding: utf-8

# # COVID-19 PROJECT
Problem Statement:
Given data about COVID-19 patients, write code to visualize the impact and
analyze the trend of rate of infection and recovery as well as make predictions
about the number of cases expected a week in future based on the current
trends.
Dataset:
CSV and Excel files containing data about the number of COVID-19 confirmed
deaths and recovered patients both around the world and in India. Download Link
Guidelines:
● Use pandas to accumulate data from multiple data files.
● Use plotly (visualization library) to create interactive visualizations.
● Use Facebook prophet library to make time series models.
● Visualize the prediction by combining these technologies.
# In[1]:


#import libraries
import numpy as np 
import pandas as pd 
import seaborn as sns
import matplotlib.pyplot as plt 
import plotly.express as px
import warnings


# In[2]:


#load data
df=pd.read_csv(r"C:\Users\Dell\Downloads\covid_19_clean_complete (4)(1).csv")
df


# In[3]:


df.columns


# In[4]:


df.info()


# In[5]:


#renaming the column names
df.rename(columns={"Province/State":"State","Country/Region":"Country"},inplace=True)


# In[7]:


df.isnull().sum()


# In[8]:


df.duplicated().sum()


# In[6]:


df.head()


# In[7]:


#Total no of active cases
df["Active"].sum()


# In[8]:


#Total no of confirmed cases
df["Confirmed"].sum()


# In[9]:


#Total no of deaths
df["Deaths"].sum()


# In[10]:


#Total no of recovered
df["Recovered"].sum()


# In[11]:


df["Date"].unique()


# In[12]:


#filtering  the data
top=df[df["Date"]=='2020-07-27']
top


# In[13]:


world=top.groupby('Country').sum()[['Confirmed',"Deaths","Recovered","Active"]].reset_index()
world


# In[14]:


#visualisation of active cases
figure=px.choropleth(world,locations="Country",locationmode="country names",color="Active",
                     hover_name="Country",range_color=[1,1500],color_continuous_scale="Blues",
                     title="Countries with active cases")
figure.show()


# In[ ]:





# In[15]:


#visualisation of recovered cases
figure=px.choropleth(world,locations="Country",locationmode="country names",color="Recovered",
                     hover_name="Country",range_color=[1,1500],color_continuous_scale="Blues",
                     title="Countries with recovered cases")
figure.show()


# In[16]:


#visualisation of Death cases
figure=px.choropleth(world,locations="Country",locationmode="country names",color="Deaths",
                     hover_name="Country",range_color=[1,1500],color_continuous_scale="Blues",
                     title="Countries with death cases")
figure.show()


# In[17]:


#visualisation of confirmed cases
figure=px.choropleth(world,locations="Country",locationmode="country names",color="Confirmed",
                     hover_name="Country",range_color=[1,1500],color_continuous_scale="Blues",
                     title="Countries with confirmed cases")
figure.show()


# # Analysing the trends in active,deaths,confirmed and recovered cases

# In[235]:


#Trend of Confirmed cases
plt.figure(figsize=(42,10))
plt.xticks(rotation=90,fontsize=10)
plt.yticks(rotation=90,fontsize=15)
plt.xlabel("Dates",fontsize=30)
plt.ylabel("Total cases",fontsize=30)
plt.title("Worldwide Confirmed Cases Over Time",fontsize=30)
total_cases=df.groupby("Date")["Date","Confirmed"].sum().reset_index()
total_cases
ax=sns.pointplot(x=total_cases.Date,y=total_cases.Confirmed,color='r')
ax.set(xlabel="Dates",ylabel="Total cases")
plt.grid()


# INFERENCE: Total no of Confirmed cases across the world was almost constant till "2020-03-15" and started increasing drastically 

# In[236]:


#Trend of Active cases
plt.figure(figsize=(42,10))
plt.xticks(rotation=90,fontsize=10)
plt.yticks(rotation=90,fontsize=15)
plt.xlabel("Dates",fontsize=30)
plt.ylabel("Total cases",fontsize=30)
plt.title("Worldwide Active Cases Over Time",fontsize=30)
total_cases=df.groupby("Date")["Date","Active"].sum().reset_index()
total_cases
ax=sns.pointplot(x=total_cases.Date,y=total_cases.Active,color='r')
ax.set(xlabel="Dates",ylabel="Total cases")
plt.grid()


# INFERENCE: Total no of Active cases acorss the world was almost constant till "2020-03-16" and started increasing drastically with slight decrement in "2020-06-08" and "2020-07-02"                

# In[237]:


#Trend of Recovered cases
plt.figure(figsize=(42,10))
plt.xticks(rotation=90,fontsize=10)
plt.yticks(rotation=90,fontsize=15)
plt.xlabel("Dates",fontsize=30)
plt.ylabel("Total cases",fontsize=30)
plt.title("Worldwide Recovered Cases Over Time",fontsize=30)
total_cases=df.groupby("Date")["Date","Recovered"].sum().reset_index()
total_cases
ax=sns.pointplot(x=total_cases.Date,y=total_cases.Recovered,color='r')
ax.set(xlabel="Dates",ylabel="Total cases")
plt.grid()


# INFERENCE:Total no of Recovered cases across the world was almost constant till "2020-03-25" and started increasing drastically.

# In[238]:


#Trend of Death cases
plt.figure(figsize=(42,10))
plt.xticks(rotation=90,fontsize=10)
plt.yticks(rotation=90,fontsize=15)
plt.xlabel("Dates",fontsize=30)
plt.ylabel("Total cases",fontsize=30)
plt.title("Worldwide Death Cases Over Time",fontsize=30)
total_cases=df.groupby("Date")["Date","Deaths"].sum().reset_index()
total_cases
ax=sns.pointplot(x=total_cases.Date,y=total_cases.Deaths,color='r')
ax.set(xlabel="Dates",ylabel="Total cases")
plt.grid()


# INFERENCE: Total no of Death cases acorss the world was almost constant till "2020-03-17" and started increasing drastically.

# # Top 20 countries having most no of Confirmed,Active,Recovered and Death cases

# # About Confirmed Cases

# Top 20 countries having most no of Confirmed cases

# In[239]:


top_confirmed=df.groupby(by="Country")["Confirmed"].sum().sort_values(ascending=False).head(20).reset_index()
top_confirmed


# In[240]:


top_confirmed=df.groupby(by="Country")["Confirmed"].sum().sort_values(ascending=False).head(20).reset_index()
top_confirmed
plt.figure(figsize=(42,20))
plt.xticks(rotation=90,fontsize=10)
plt.yticks(fontsize=30)
plt.xlabel("Total cases",fontsize=30)
plt.ylabel("Country",fontsize=40)
plt.title("Top 20 countries having most no of Confirmed cases",fontsize=30)
ax=sns.barplot(x=top_confirmed.Confirmed,y=top_confirmed.Country,color='r')
ax.set(xlabel="Total cases",ylabel="Country")

INFERENCE:Top 5 countries having confirmed cases:
1.US
2.Brazil
3.Russia
4.India
5.Spain
# In[241]:


#The country US with Confirmed,Active,Recovered and Death cases
US=df[df.Country=="US"]
US=US.groupby(by="Date")["Confirmed","Active","Recovered","Deaths"].sum().reset_index()
US


# In[242]:


# Visualising the Confirmed,Active,Recovered and Death cases in US
plt.figure(figsize=(25,15))
sns.pointplot(data=US,x=US.index,y="Confirmed",color="blue",label="Confirmed")
sns.pointplot(data=US,x=US.index,y="Active",color="green",label="Active")
sns.pointplot(data=US,x=US.index,y="Recovered",color="yellow",label="Recovered")
sns.pointplot(data=US,x=US.index,y="Deaths",color="red",label="Deaths")
plt.xticks(rotation=90,fontsize=10)
plt.xlabel("No of days",fontsize=15)
plt.ylabel("cases",fontsize=15)
plt.title("Confirmed,Active,Recovered and Death cases in US",fontsize=30)
plt.legend()


# In[243]:


#The country Brazil with Confirmed,Active,Recovered and Death cases
Brazil=df[df.Country=="Brazil"]
Brazil=Brazil.groupby(by="Date")["Confirmed","Active","Recovered","Deaths"].sum().reset_index()
Brazil


# In[244]:


# Visualising the Confirmed,Active,Recovered and Death cases in Brazil
plt.figure(figsize=(25,15))
sns.pointplot(data=Brazil,x=Brazil.index,y="Confirmed",color="blue",label="Confirmed")
sns.pointplot(data=Brazil,x=Brazil.index,y="Active",color="green",label="Active")
sns.pointplot(data=Brazil,x=Brazil.index,y="Recovered",color="yellow",label="Recovered")
sns.pointplot(data=Brazil,x=Brazil.index,y="Deaths",color="red",label="Deaths")
plt.xticks(rotation=90,fontsize=10)
plt.xlabel("No of days",fontsize=15)
plt.ylabel("cases",fontsize=15)
plt.title("Confirmed,Active,Recovered and Death cases in Brazil",fontsize=30)
plt.legend()


# In[245]:


#The country Russia with confirmed,Active,Recovered and Death cases
Russia=df[df.Country=="Russia"]
Russia=Russia.groupby(by="Date")["Confirmed","Active","Recovered","Deaths"].sum().reset_index()
Russia


# In[246]:


# Visualising the Confirmed,Active,Recovered and Death cases in Russia
plt.figure(figsize=(25,15))
sns.pointplot(data=Russia,x=Russia.index,y="Confirmed",color="blue",label="Confirmed")
sns.pointplot(data=Russia,x=Russia.index,y="Active",color="green",label="Active")
sns.pointplot(data=Russia,x=Russia.index,y="Recovered",color="yellow",label="Recovered")
sns.pointplot(data=Russia,x=Russia.index,y="Deaths",color="red",label="Deaths")
plt.xticks(rotation=90,fontsize=10)
plt.xlabel("No of days",fontsize=15)
plt.ylabel("cases",fontsize=15)
plt.title("Confirmed,Active,Recovered and Death cases in Russia",fontsize=30)
plt.legend()


# In[247]:


#The country India with confirmed,Active,Recovered and Death cases
India=df[df.Country=="India"]
India=India.groupby(by="Date")["Confirmed","Active","Recovered","Deaths"].sum().reset_index()
India


# In[248]:


# Visualising the Confirmed,Active,Recovered and Death cases in India
plt.figure(figsize=(25,15))
sns.pointplot(data=India,x=India.index,y="Confirmed",color="blue",label="Confirmed")
sns.pointplot(data=India,x=India.index,y="Active",color="green",label="Active")
sns.pointplot(data=India,x=India.index,y="Recovered",color="yellow",label="Recovered")
sns.pointplot(data=India,x=India.index,y="Deaths",color="red",label="Deaths")
plt.xticks(rotation=90,fontsize=10)
plt.xlabel("No of days",fontsize=15)
plt.ylabel("cases",fontsize=15)
plt.title("Confirmed,Active,Recovered and Death cases in India",fontsize=30)
plt.legend()


# In[249]:


#The country Spain with confirmed,Active,Recovered and Death cases
Spain=df[df.Country=="Spain"]
Spain=Spain.groupby(by="Date")["Confirmed","Active","Recovered","Deaths"].sum().reset_index()
Spain


# In[250]:


# Visualising the Confirmed,Active,Recovered and Death cases in Spain
plt.figure(figsize=(25,15))
sns.pointplot(data=Spain,x= Spain.index,y="Confirmed",color="blue",label="Confirmed")
sns.pointplot(data=Spain,x= Spain.index,y="Active",color="green",label="Active")
sns.pointplot(data=Spain,x= Spain.index,y="Recovered",color="yellow",label="Recovered")
sns.pointplot(data=Spain,x= Spain.index,y="Deaths",color="red",label="Deaths")
plt.xticks(rotation=90,fontsize=10)
plt.xlabel("No of days",fontsize=15)
plt.ylabel("cases",fontsize=15)
plt.title("Confirmed,Active,Recovered and Death cases in Spain",fontsize=30)
plt.legend()


# # Visualising the Confirmed Cases in US,Brazil,Russia,India and Spain

# In[251]:


plt.figure(figsize=(25,15))
sns.pointplot(data=US,x= Spain.index,y="Confirmed",color="blue",label="US")
sns.pointplot(data=Brazil,x= Spain.index,y="Confirmed",color="green",label="Brazil")
sns.pointplot(data=Russia,x= Spain.index,y="Confirmed",color="yellow",label="Russia")
sns.pointplot(data=India,x= Spain.index,y="Confirmed",color="red",label="India")
sns.pointplot(data=Spain,x= Spain.index,y="Confirmed",color="violet",label="Spain")
plt.xticks(rotation=90,fontsize=10)
plt.xlabel("No of days",fontsize=15)
plt.ylabel("Countries",fontsize=15)
plt.title("Top 5 countries with confirmed Cases",fontsize=30)
plt.legend()


# # About Active Cases

# Top 20 countries having most number of Active cases

# In[252]:


top_active = df.groupby(by='Country')["Active"].sum().sort_values(ascending=False).head(20).reset_index()
top_active


# In[253]:


plt.figure(figsize=(40,25))
plt.xticks(rotation=90,fontsize=20)
plt.yticks(fontsize=25)
plt.xlabel('Total Cases',fontsize=30)
plt.ylabel('Country',fontsize=30)
plt.title("Top 20 countries having most number of Active cases",fontsize=30)
ax = sns.barplot(x=top_active.Active,y=top_active.Country,color='r')
ax.set(xlabel='Total Cases',ylabel='Country')

INFERENCE:Top 5 countries having confirmed cases:
1.US
2.Brazil
3.United Kingdom
4.Russia
5.India
# In[254]:


#The country UK with Confirmed,Active,Recovered and Death cases
UK=df[df.Country=="United Kingdom"]
UK=UK.groupby(by="Date")["Confirmed","Active","Recovered","Deaths"].sum().reset_index()
UK


# In[255]:


# Visualising the Confirmed,Active,Recovered and Death cases in UK

plt.figure(figsize=(25,15))
sns.pointplot(data=UK,x=UK.index,y="Confirmed",color="blue",label="Confirmed")
sns.pointplot(data=UK,x=UK.index,y="Active",color="green",label="Active")
sns.pointplot(data=UK,x=UK.index,y="Recovered",color="yellow",label="Recovered")
sns.pointplot(data=UK,x=UK.index,y="Deaths",color="red",label="Deaths")
plt.xticks(rotation=90,fontsize=10)
plt.xlabel("No of days",fontsize=15)
plt.ylabel("cases",fontsize=15)
plt.title("Confirmed,Active,Recovered and Death cases in UK",fontsize=30)
plt.legend()


# # Visualising the Active Cases in US,Brazil,UK,Russia and India

# plt.figure(figsize=(25,15))
# sns.pointplot(data=US,x= US.index,y="Active",color="blue",label="US")
# sns.pointplot(data=Brazil,x= Brazil.index,y="Active",color="green",label="Brazil")
# sns.pointplot(data=UK,x= UK.index,y="Active",color="yellow",label="Uk")
# sns.pointplot(data=Russia,x= Russia.index,y="Active",color="red",label="Russia")
# sns.pointplot(data=India,x= India.index,y="Active",color="violet",label="India")
# plt.xticks(rotation=90,fontsize=10)
# plt.xlabel("No of days",fontsize=15)
# plt.ylabel("Active Cases",fontsize=15)
# plt.title("Top 5 countries with Active Cases",fontsize=30)
# plt.legend()

# # About Recovered Cases

# Top 20 countries having most number of Recovered cases

# In[256]:


top_recovered = df.groupby(by='Country')["Recovered"].sum().sort_values(ascending=False).head(20).reset_index()
top_recovered


# In[257]:


plt.figure(figsize=(40,25))
plt.xticks(rotation=90,fontsize=20)
plt.yticks(fontsize=25)
plt.xlabel('Total Cases',fontsize=30)
plt.ylabel('Country',fontsize=30)
plt.title("Top 20 countries having most number of Recovered cases",fontsize=30)
ax = sns.barplot(x=top_recovered.Recovered,y=top_recovered.Country,color='r')
ax.set(xlabel='Total Cases',ylabel='Country')


INFERENCE:Top 5 countries having recovered cases:
1.US
2.Brazil
3.Russia
4.India
5.Germany
# In[258]:


#The country germany with Confirmed,Active,Recovered and Death cases
GY=df[df.Country=="Germany"]
GY=GY.groupby(by="Date")["Confirmed","Active","Recovered","Deaths"].sum().reset_index()
GY


# In[259]:


# Visualising the Confirmed,Active,Recovered and Death cases in Germany
plt.figure(figsize=(25,15))
sns.pointplot(data=GY,x=GY.index,y="Confirmed",color="blue",label="Confirmed")
sns.pointplot(data=GY,x=GY.index,y="Active",color="green",label="Active")
sns.pointplot(data=GY,x=GY.index,y="Recovered",color="yellow",label="Recovered")
sns.pointplot(data=GY,x=GY.index,y="Deaths",color="red",label="Deaths")
plt.xticks(rotation=90,fontsize=10)
plt.xlabel("No of days",fontsize=15)
plt.ylabel("cases",fontsize=15)
plt.title("Confirmed,Active,Recovered and Death cases in Germany",fontsize=30)
plt.legend()


# 
# 
# # Visualising the Recovered Cases in US,Brazil,Russia,India and Germany

# In[260]:


plt.figure(figsize=(25,15))
sns.pointplot(data=US,x= US.index,y="Recovered",color="blue",label="US")
sns.pointplot(data=Brazil,x= Brazil.index,y="Recovered",color="green",label="Brazil")
sns.pointplot(data=Russia,x= Russia.index,y="Recovered",color="yellow",label="Russia")
sns.pointplot(data=India,x= India.index,y="Recovered",color="red",label="India")
sns.pointplot(data=GY,x= GY.index,y="Recovered",color="violet",label="Germany")
plt.xticks(rotation=90,fontsize=10)
plt.xlabel("No of days",fontsize=15)
plt.ylabel("Active Cases",fontsize=15)
plt.title("Top 5 countries with Recovered Cases",fontsize=30)
plt.legend()


# # About Death Cases

# Top 20 countries having most number of Death cases

# In[261]:


top_death = df.groupby(by='Country')["Deaths"].sum().sort_values(ascending=False).head(20).reset_index()
top_death


# In[262]:


plt.figure(figsize=(40,25))
plt.xticks(rotation=90,fontsize=20)
plt.yticks(fontsize=25)
plt.xlabel('Total Cases',fontsize=30)
plt.ylabel('Country',fontsize=30)
plt.title("Top 20 countries having most number of Death cases",fontsize=30)
ax = sns.barplot(x=top_death.Deaths,y=top_death.Country,color='r')
ax.set(xlabel='Total Cases',ylabel='Country')

INFERENCE:Top 5 countries having recovered cases:
1.US
2.United Kingdom
3.Brazil
4.Italy
5.France
# In[263]:


#The country Italy with Confirmed,Active,Recovered and Death cases
Italy=df[df.Country=="Italy"]
Italy=Italy.groupby(by="Date")["Confirmed","Active","Recovered","Deaths"].sum().reset_index()
Italy


# In[264]:


#Visualising the Confirmed,Active,Recovered and Death cases in Italy
plt.figure(figsize=(25,15))
sns.pointplot(data=Italy,x=Italy.index,y="Confirmed",color="blue",label="Confirmed")
sns.pointplot(data=Italy,x=Italy.index,y="Active",color="green",label="Active")
sns.pointplot(data=Italy,x=Italy.index,y="Recovered",color="yellow",label="Recovered")
sns.pointplot(data=Italy,x=Italy.index,y="Deaths",color="red",label="Deaths")
plt.xticks(rotation=90,fontsize=10)
plt.xlabel("No of days",fontsize=15)
plt.ylabel("cases",fontsize=15)
plt.title("Confirmed,Active,Recovered and Death cases in Italy",fontsize=30)
plt.legend()


# In[265]:


#The country France with Confirmed,Active,Recovered and Death cases
France=df[df.Country=="France"]
France=France.groupby(by="Date")["Confirmed","Active","Recovered","Deaths"].sum().reset_index()
France


# In[266]:


#Visualising the Confirmed,Active,Recovered and Death cases in France
plt.figure(figsize=(25,15))
sns.pointplot(data=France,x=France.index,y="Confirmed",color="blue",label="Confirmed")
sns.pointplot(data=France,x=France.index,y="Active",color="green",label="Active")
sns.pointplot(data=France,x=France.index,y="Recovered",color="yellow",label="Recovered")
sns.pointplot(data=France,x=France.index,y="Deaths",color="red",label="Deaths")
plt.xticks(rotation=90,fontsize=10)
plt.xlabel("No of days",fontsize=15)
plt.ylabel("cases",fontsize=15)
plt.title("Confirmed,Active,Recovered and Death cases in France",fontsize=30)
plt.legend()


# # Visualising the Death
# 
# Cases in US,UK,Brazil,Italy and France

# In[267]:


plt.figure(figsize=(25,15))
sns.pointplot(data=US,x=US.index,y="Deaths",color="blue",label="US")
sns.pointplot(data=UK,x=UK.index,y="Deaths",color="green",label="UK")
sns.pointplot(data=Brazil,x=Brazil.index,y="Deaths",color="yellow",label="Brazil")
sns.pointplot(data=Italy,x=Italy.index,y="Deaths",color="red",label="Italy")
sns.pointplot(data=France,x=France.index,y="Deaths",color="violet",label="France")
plt.xticks(rotation=90,fontsize=10)
plt.xlabel("No of days",fontsize=15)
plt.ylabel("Active Cases",fontsize=15)
plt.title("Top 5 countries with Death Cases",fontsize=30)
plt.legend()


# # Forecasting using FBPROPHET

# In[268]:


get_ipython().system('pip install prophet')


# In[269]:


from prophet import Prophet


# In[270]:


df.info()


# In[271]:


df["Date"]=pd.to_datetime(df["Date"])


# In[272]:


df.info()


# In[273]:


confirmed=df.groupby("Date").sum()["Confirmed"].reset_index()
confirmed


# In[344]:


active=df.groupby("Date").sum()["Active"].reset_index()
active


# In[345]:


recovered=df.groupby("Date").sum()["Recovered"].reset_index()
recovered


# In[346]:


death=df.groupby("Date").sum()["Deaths"].reset_index()
death


# # Forecasting of Confirmed Cases

# In[347]:


#step 1:renaming the columns
confirmed.rename(columns={"Date":"ds","Confirmed":"y"},inplace=True)
confirmed


# In[348]:


#step 2:creating an object of Prophet() 
conf_model=Prophet(interval_width=0.95)


# In[349]:


#step 3:training the model
conf_model.fit(confirmed)


# In[350]:


#step 4:forecasting for next 7 days
future=conf_model.make_future_dataframe(periods=7)
future


# In[351]:


forecast=conf_model.predict(future)
forecast[["ds","yhat","yhat_lower","yhat_upper"]]


# In[352]:


confirmed_plot=conf_model.plot(forecast)


# In[353]:


confirmed_forecast_plot=conf_model.plot_components(forecast)


# # Forecasting of Active cases

# In[367]:


#step 1:renaming the columns
active.rename(columns={"Date":"ds","Active":"y"},inplace=True)
active


# In[368]:


#step 2:creating an object of Prophet() 
active_model=Prophet(interval_width=0.95)


# In[369]:


#step 3:training the model 
active_model.fit(active)


# In[370]:


#step 4:forecasting for next 7 days
future=active_model.make_future_dataframe(periods=7)
future


# In[371]:


forecast=active_model.predict(future)
forecast[["ds","yhat","yhat_lower","yhat_upper"]].tail(7)


# In[373]:


active_plot=active_model.plot(forecast)


# In[282]:


active_forecast_plot=active_model.plot_components(forecast)


# # Forecasting of Recovered Cases

# In[374]:


#step 1:renaming the columns
recovered.rename(columns={"Date":"ds","Recovered":"y"},inplace=True)
recovered


# In[375]:


#step 2:creating an object of Prophet() 
recovered_model=Prophet(interval_width=0.95)


# In[376]:


#step 3:training the model 
recovered_model.fit(recovered)


# In[377]:


#step 4:forecasting for next 7 days
future=recovered_model.make_future_dataframe(periods=7)
future


# In[378]:


forecast=recovered_model.predict(future)
forecast[["ds","yhat","yhat_lower","yhat_upper"]].tail(7)


# In[380]:


recovered_plot=recovered_model.plot(forecast)


# In[381]:


recovered_forecast_plot=recovered_model.plot_components(forecast)


# # Forecasting of Death Cases

# In[382]:


#step 1:renaming the columns
death.rename(columns={"Date":"ds","Deaths":"y"},inplace=True)
death


# In[383]:


#step 2:creating an object of Prophet() 
death_model=Prophet(interval_width=0.95)


# In[384]:


#step 3:training the model 
death_model.fit(death)


# In[385]:


#step 4:forecasting for next 7 days
future=death_model.make_future_dataframe(periods=7)
future


# In[386]:


forecast=death_model.predict(future)
forecast[["ds","yhat","yhat_lower","yhat_upper"]].tail(7)


# In[387]:


death_plot=death_model.plot(forecast)


# In[388]:


death_forecast_plot=death_model.plot_components(forecast)


# In[419]:


#visualisation of active cases
figure=px.choropleth(world,locations="Country",locationmode="country names",color="Active",
                     hover_name="Country",range_color=[1,1500],color_continuous_scale="Blues",
                     title="Countries with active cases")
figure.show()


# In[ ]:





# In[ ]:




